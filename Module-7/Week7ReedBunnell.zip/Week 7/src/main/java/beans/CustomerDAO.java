package beans;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * CustomerDAO
 * Handles all DB read/insert operations for CustomerRecord.
 * Uses JDBC + PreparedStatement for safer SQL execution.
 */
public class CustomerDAO {

    // TODO: Keep these aligned with YOUR Part 1 DB config:
    private static final String JDBC_URL  = "jdbc:mysql://localhost:3306/db";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASS = "YOUR_PASSWORD";

    // TODO: Replace with your real table name from Part 1:
    private static final String TABLE = "customer_records";

    /** Get a DB connection. */
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
    }

    /**
     * Insert a new record. Key value is NOT provided by the form.
     * Assumes customerId is AUTO_INCREMENT in the DB.
     */
    public void insert(CustomerRecord rec) throws SQLException {
        String sql = "INSERT INTO " + TABLE + " (full_name, email, membership_level, account_balance) " +
                     "VALUES (?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, rec.getFullName());
            ps.setString(2, rec.getEmail());
            ps.setString(3, rec.getMembershipLevel());
            ps.setDouble(4, rec.getAccountBalance());

            ps.executeUpdate();
        }
    }

    /** Read all records for display. */
    public List<CustomerRecord> getAll() throws SQLException {
        List<CustomerRecord> list = new ArrayList<>();

        String sql = "SELECT customer_id, full_name, email, membership_level, account_balance " +
                     "FROM " + TABLE + " ORDER BY customer_id DESC";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                CustomerRecord rec = new CustomerRecord();
                rec.setCustomerId(rs.getInt("customer_id"));
                rec.setFullName(rs.getString("full_name"));
                rec.setEmail(rs.getString("email"));
                rec.setMembershipLevel(rs.getString("membership_level"));
                rec.setAccountBalance(rs.getDouble("account_balance"));
                list.add(rec);
            }
        }

        return list;
    }
}
