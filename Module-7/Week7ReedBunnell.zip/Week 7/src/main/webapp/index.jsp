<%@ page import="java.util.*" %>
<%@ page import="beans.CustomerRecord" %>
<%@ page import="beans.CustomerDAO" %>
<%@ page contentType="text/html; charset=UTF-8" %>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <title>Project Part 2 - Add + Display Records</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 24px; }
    form { padding: 12px; border: 1px solid #ccc; border-radius: 8px; max-width: 700px; }
    .row { margin-bottom: 10px; }
    label { display: inline-block; width: 160px; font-weight: bold; }
    input, select { padding: 6px; width: 320px; }
    table { border-collapse: collapse; margin-top: 20px; width: 100%; }
    th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
    thead { background: #f2f2f2; }
    .msg { margin: 12px 0; padding: 10px; border-radius: 6px; }
    .ok { background: #e8fff0; border: 1px solid #9be3b1; }
    .err { background: #ffecec; border: 1px solid #f0a0a0; }
    .desc { max-width: 900px; }
  </style>
</head>

<body>
  <h1>Project Part 2: Add a Record (JavaBean) + Display All Records</h1>

  <p class="desc">
    This page collects user input via an HTML form and inserts a new record into the existing database table
    using a JavaBean/DAO. After submission, the page displays all records currently stored in the database
    in an HTML table format.
  </p>

<%
    // ----- Scriptlet area: handle insert + fetch list -----
    String message = null;
    boolean isError = false;

    CustomerDAO dao = new CustomerDAO();

    // Only attempt insert if this is a POST and a known parameter exists
    if ("POST".equalsIgnoreCase(request.getMethod()) && request.getParameter("fullName") != null) {
        try {
            // Build bean from form fields (key is NOT provided by user)
            CustomerRecord rec = new CustomerRecord();
            rec.setFullName(request.getParameter("fullName"));
            rec.setEmail(request.getParameter("email"));
            rec.setMembershipLevel(request.getParameter("membershipLevel"));

            // Convert balance safely
            String balStr = request.getParameter("accountBalance");
            double balance = (balStr == null || balStr.isBlank()) ? 0.0 : Double.parseDouble(balStr);
            rec.setAccountBalance(balance);

            // Insert via DAO
            dao.insert(rec);
            message = "Record added successfully!";
        } catch (Exception ex) {
            isError = true;
            message = "Error adding record: " + ex.getMessage();
        }
    }

    // Always load all rows for display
    List<CustomerRecord> records = new ArrayList<>();
    try {
        records = dao.getAll();
    } catch (Exception ex) {
        isError = true;
        message = "Error loading records: " + ex.getMessage();
    }
%>

  <!-- All HTML OUTSIDE of scriptlets -->
  <% if (message != null) { %>
    <div class="msg <%= (isError ? "err" : "ok") %>"><%= message %></div>
  <% } %>

  <h2>Add New Record</h2>
  <p>
    Enter the customer information below. The key value (Customer ID) is generated automatically when the form is submitted.
  </p>

  <form method="post" action="index.jsp">
    <div class="row">
      <label for="fullName">Full Name:</label>
      <input id="fullName" name="fullName" type="text" required />
    </div>

    <div class="row">
      <label for="email">Email:</label>
      <input id="email" name="email" type="email" required />
    </div>

    <div class="row">
      <label for="membershipLevel">Membership Level:</label>
      <select id="membershipLevel" name="membershipLevel" required>
        <option value="Basic">Basic</option>
        <option value="Silver">Silver</option>
        <option value="Gold">Gold</option>
        <option value="Platinum">Platinum</option>
      </select>
    </div>

    <div class="row">
      <label for="accountBalance">Account Balance:</label>
      <input id="accountBalance" name="accountBalance" type="number" step="0.01" value="0.00" />
    </div>

    <div class="row">
      <label></label>
      <input type="submit" value="Add Record" />
    </div>
  </form>

  <h2>All Records (Database Table)</h2>
  <p>
    The table below displays all records currently stored in the database. Each field is displayed in its own column.
  </p>

  <table>
    <thead>
      <tr>
        <th>Customer ID (Key)</th>
        <th>Full Name</th>
        <th>Email</th>
        <th>Membership Level</th>
        <th>Account Balance</th>
      </tr>
    </thead>
    <tbody>
      <% for (CustomerRecord r : records) { %>
        <tr>
          <td><%= r.getCustomerId() %></td>
          <td><%= r.getFullName() %></td>
          <td><%= r.getEmail() %></td>
          <td><%= r.getMembershipLevel() %></td>
          <td><%= String.format("%.2f", r.getAccountBalance()) %></td>
        </tr>
      <% } %>
    </tbody>
  </table>

</body>
</html>
