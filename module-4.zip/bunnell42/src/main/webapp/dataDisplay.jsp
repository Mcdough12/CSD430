<%@ page import="beans.CustomerRecord" %>
<%@ page contentType="text/html; charset=UTF-8" language="java" %>

<%
    CustomerRecord record = new CustomerRecord();

    record.setCustomerId("C1029");
    record.setFullName("Reed Bunnell");
    record.setEmail("reed@example.com");
    record.setMembershipLevel("Gold");
    record.setAccountBalance(245.75);
%>

    record.setCustomerId("C1029");
    record.setFullName("Reed Bunnell");
    record.setEmail("reed@example.com");
    record.setMembershipLevel("Gold");
    record.setAccountBalance(245.75);
%>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Module 4 Data Display</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 24px; }
    table { border-collapse: collapse; width: 900px; max-width: 100%; }
    th, td { border: 1px solid #bbb; padding: 10px; text-align: left; }
    th { background: #f2f2f2; width: 25%; }
  </style>
</head>
<body>
  <h1>Module 4: JavaBean + JSP Data Display</h1>
  <p><strong>Student:</strong> Reed Bunnell</p>
  <p>This table displays data stored in a Serializable JavaBean.</p>

  <table>
    <tr><th>Field</th><th>Value</th><th>Description</th></tr>
    <tr><td>customerId</td><td><%= record.getCustomerId() %></td><td>Unique customer identifier</td></tr>
    <tr><td>fullName</td><td><%= record.getFullName() %></td><td>Customer full name</td></tr>
    <tr><td>email</td><td><%= record.getEmail() %></td><td>Email address</td></tr>
    <tr><td>membershipLevel</td><td><%= record.getMembershipLevel() %></td><td>Membership tier</td></tr>
    <tr><td>accountBalance</td><td>$<%= String.format("%.2f", record.getAccountBalance()) %></td><td>Account balance</td></tr>
  </table>
</body>
</html>
