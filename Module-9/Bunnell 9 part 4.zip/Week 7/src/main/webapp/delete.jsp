<%@ page import="java.util.*" %>
<%@ page import="beans.*" %>

<!DOCTYPE html>
<html>
<head>
<title>Project Part 4 - Delete Records</title>

<style>

body{
    font-family: Arial;
    margin:40px;
}

form{
    border:1px solid #ccc;
    padding:20px;
    max-width:700px;
    padding:20px;
    border-radius:10px;
}

table{
    border-collapse: collapse;
    width:100%;
    margin-top:25px;
}

th, td{
    border:1px solid #ccc;
    padding:8px;
}

thead{
    background:#f2f2f2;
}

select{
    padding:8px;
    width:200px;
}

</style>

</head>

<body>

<h1>Project Part 4: Record Deletion System</h1>

<p>
This page displays all database records in table format and allows the user to delete
a record by selecting the key value from the dropdown list. After deletion, the page
refreshes and displays remaining records.
</p>

<%
CustomerDAO dao = new CustomerDAO();

try{

    String idStr = request.getParameter("customerId");

    if(idStr != null){
        int id = Integer.parseInt(idStr);
        dao.delete(id);
    }

    List<CustomerRecord> records = dao.getAll();
    List<Integer> ids = dao.getAllIds();
%>

<h2>Database Records</h2>

<table>

<thead>
<tr>
<th>ID</th>
<th>Full Name</th>
<th>Email</th>
<th>Membership Level</th>
<th>Account Balance</th>
</tr>
</thead>

<tbody>

<%
for(CustomerRecord r : records){
%>

<tr>
<td><%= r.getCustomerId() %></td>
<td><%= r.getFullName() %></td>
<td><%= r.getEmail() %></td>
<td><%= r.getMembershipLevel() %></td>
<td><%= String.format("%.2f", r.getAccountBalance()) %></td>
</tr>

<%
}
%>

</tbody>

</table>

<h2>Delete Record</h2>

<form method="get" action="delete.jsp">

<label>Select Key ID to Delete:</label><br/>

<select name="customerId" required>

<%
for(Integer id : ids){
%>
<option value="<%=id%>"><%=id%></option>
<%
}
%>

</select>

<br/><br/>

<input type="submit" value="Delete Selected Record"/>

</form>

<%
}
catch(Exception e){
%>

<p style="color:red">
Database Error: <%= e.getMessage() %>
</p>

<%
}
%>

</body>
</html>