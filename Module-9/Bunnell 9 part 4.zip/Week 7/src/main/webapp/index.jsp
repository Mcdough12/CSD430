<%@ page import="java.util.*" %>
<%@ page import="beans.*" %>
<%@ page contentType="text/html; charset=UTF-8" %>

<!DOCTYPE html>
<html>
<head>
<title>Project Part 3 - Record Selection</title>

<style>
body{
    font-family: Arial, sans-serif;
    margin:40px;
}

form{
    border:1px solid #ccc;
    padding:20px;
    border-radius:10px;
    max-width:600px;
}

select{
    padding:8px;
    width:200px;
    margin-bottom:15px;
}

input[type=submit]{
    padding:8px 16px;
}

</style>

</head>

<body>

<h1>Project Part 3 - Update Database Record</h1>

<p>
Select a record key value from the dropdown list below to update an existing database record.
All key values are loaded dynamically from the database using a JavaBean.
</p>

<%
CustomerDAO dao = new CustomerDAO();
List<Integer> ids = new ArrayList<>();

try{
    ids = dao.getAllIds();
}
catch(Exception e){
    out.println("Database error: " + e.getMessage());
}
%>

<h2>Select Record to Update</h2>

<form method="get" action="updateForm.jsp">

<label>Record Key ID:</label><br/>

<select name="customerId" required>

<% for(Integer id : ids){ %>
    <option value="<%=id%>"><%=id%></option>
<% } %>

</select>

<br/>

<input type="submit" value="Load Record"/>

</form>

</body>
</html>