<%@ page import="beans.*" %>

<!DOCTYPE html>
<html>
<head>
<title>Update Result</title>

<style>
body{
    font-family: Arial;
    margin:40px;
}

table{
    border-collapse: collapse;
    width:600px;
    margin-top:20px;
}

th, td{
    border:1px solid #ccc;
    padding:8px;
}

thead{
    background:#f2f2f2;
}
</style>

</head>

<body>

<h1>Updated Record Confirmation</h1>

<%
CustomerDAO dao = new CustomerDAO();

try{

    CustomerRecord rec = new CustomerRecord();

    rec.setCustomerId(Integer.parseInt(request.getParameter("customerId")));
    rec.setFullName(request.getParameter("fullName"));
    rec.setEmail(request.getParameter("email"));
    rec.setMembershipLevel(request.getParameter("membershipLevel"));
    rec.setAccountBalance(Double.parseDouble(request.getParameter("accountBalance")));

    dao.update(rec);
%>

<h2>Record Updated Successfully</h2>

<table>

<thead>
<tr>
<th>ID</th>
<th>Full Name</th>
<th>Email</th>
<th>Membership Level</th>
<th>Account Balance</th>
</tr>
</thead>

<tbody>

<tr>
<td><%= rec.getCustomerId() %></td>
<td><%= rec.getFullName() %></td>
<td><%= rec.getEmail() %></td>
<td><%= rec.getMembershipLevel() %></td>
<td><%= String.format("%.2f", rec.getAccountBalance()) %></td>
</tr>

</tbody>

</table>

<%
}
catch(Exception e){
%>

<p style="color:red">
Update failed: <%= e.getMessage() %>
</p>

<%
}
%>

<br/>
<a href="index.jsp">Return to Selection Page</a>

</body>
</html>