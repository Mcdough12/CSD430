<%@ page import="beans.*" %>

<!DOCTYPE html>
<html>
<head>
<title>Update Record Form</title>

<style>
body{
    font-family: Arial;
    margin:40px;
}

form{
    border:1px solid #ccc;
    padding:25px;
    max-width:600px;
    border-radius:10px;
}

input, select{
    padding:8px;
    width:320px;
    margin-bottom:12px;
}
</style>

</head>

<body>

<h1>Update Selected Record</h1>

<%
CustomerDAO dao = new CustomerDAO();

String idStr = request.getParameter("customerId");
CustomerRecord rec = null;

if(idStr != null){

    try{
        int id = Integer.parseInt(idStr);
        rec = dao.getById(id);
    }
    catch(Exception e){
        out.println("Error loading record.");
    }
}
%>

<%
if(rec != null){
%>

<form method="post" action="updateResult.jsp">

<p>
Record Key (Customer ID) — Not Editable:<br/>
<b><%= rec.getCustomerId() %></b>
</p>

<input type="hidden" name="customerId" value="<%= rec.getCustomerId() %>"/>

Full Name:<br/>
<input type="text" name="fullName"
value="<%= rec.getFullName() %>" required/>

Email:<br/>
<input type="email" name="email"
value="<%= rec.getEmail() %>" required/>

Membership Level:<br/>

<select name="membershipLevel">

<option <%= rec.getMembershipLevel().equals("Basic")?"selected":"" %>>Basic</option>
<option <%= rec.getMembershipLevel().equals("Silver")?"selected":"" %>>Silver</option>
<option <%= rec.getMembershipLevel().equals("Gold")?"selected":"" %>>Gold</option>
<option <%= rec.getMembershipLevel().equals("Platinum")?"selected":"" %>>Platinum</option>

</select>

<br/>

Account Balance:<br/>

<input type="number" step="0.01"
name="accountBalance"
value="<%= rec.getAccountBalance() %>"/>

<br/>

<input type="submit" value="Update Record"/>

</form>

<%
}
else{
%>

<p>Record not found.</p>

<%
}
%>

</body>
</html>