package beans;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * CustomerDAO
 * Handles all database operations for CustomerRecord bean.
 * Includes insert, update, delete, and select methods.
 */

public class CustomerDAO {

    // ===== DATABASE CONFIGURATION =====
    private static final String JDBC_URL =
            "jdbc:mysql://localhost:3306/db";

    private static final String JDBC_USER = "root";

    private static final String JDBC_PASS =
            "YOUR_PASSWORD";

    // ===== TABLE NAME (Change if needed) =====
    private static final String TABLE = "customer_records";

    // ===== CONNECTION METHOD =====
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
                JDBC_URL,
                JDBC_USER,
                JDBC_PASS
        );
    }

    // =====================================================
    // INSERT RECORD
    // =====================================================
    public void insert(CustomerRecord rec) throws SQLException {

        String sql = "INSERT INTO " + TABLE +
                " (full_name, email, membership_level, account_balance) " +
                " VALUES (?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, rec.getFullName());
            ps.setString(2, rec.getEmail());
            ps.setString(3, rec.getMembershipLevel());
            ps.setDouble(4, rec.getAccountBalance());

            ps.executeUpdate();
        }
    }

    // =====================================================
    // UPDATE RECORD
    // =====================================================
    public void update(CustomerRecord rec) throws SQLException {

        String sql = "UPDATE " + TABLE +
                " SET full_name=?, email=?, membership_level=?, account_balance=? " +
                " WHERE customer_id=?";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, rec.getFullName());
            ps.setString(2, rec.getEmail());
            ps.setString(3, rec.getMembershipLevel());
            ps.setDouble(4, rec.getAccountBalance());
            ps.setInt(5, rec.getCustomerId());

            ps.executeUpdate();
        }
    }

    // =====================================================
    // DELETE RECORD
    // =====================================================
    public void delete(int customerId) throws SQLException {

        String sql = "DELETE FROM " + TABLE +
                " WHERE customer_id=?";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, customerId);
            ps.executeUpdate();
        }
    }

    // =====================================================
    // GET RECORD BY ID
    // =====================================================
    public CustomerRecord getById(int customerId) throws SQLException {

        CustomerRecord rec = null;

        String sql = "SELECT customer_id, full_name, email, membership_level, account_balance " +
                "FROM " + TABLE + " WHERE customer_id=?";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, customerId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                rec = new CustomerRecord();

                rec.setCustomerId(rs.getInt("customer_id"));
                rec.setFullName(rs.getString("full_name"));
                rec.setEmail(rs.getString("email"));
                rec.setMembershipLevel(rs.getString("membership_level"));
                rec.setAccountBalance(rs.getDouble("account_balance"));
            }
        }

        return rec;
    }

    // =====================================================
    // GET ALL RECORDS
    // =====================================================
    public List<CustomerRecord> getAll() throws SQLException {

        List<CustomerRecord> list = new ArrayList<>();

        String sql = "SELECT customer_id, full_name, email, membership_level, account_balance " +
                "FROM " + TABLE + " ORDER BY customer_id";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                CustomerRecord rec = new CustomerRecord();

                rec.setCustomerId(rs.getInt("customer_id"));
                rec.setFullName(rs.getString("full_name"));
                rec.setEmail(rs.getString("email"));
                rec.setMembershipLevel(rs.getString("membership_level"));
                rec.setAccountBalance(rs.getDouble("account_balance"));

                list.add(rec);
            }
        }

        return list;
    }

    // =====================================================
    // GET ALL KEY IDS (FOR DROPDOWN LIST)
    // =====================================================
    public List<Integer> getAllIds() throws SQLException {

        List<Integer> ids = new ArrayList<>();

        String sql = "SELECT customer_id FROM " + TABLE +
                " ORDER BY customer_id";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                ids.add(rs.getInt("customer_id"));
            }
        }

        return ids;
    }
}