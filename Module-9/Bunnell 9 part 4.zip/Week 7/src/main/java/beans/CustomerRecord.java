package beans;

import java.io.Serializable;

/**
 * CustomerRecord JavaBean
 * Stores customer data for JSP display and DB insert/read.
 * Follows JavaBean conventions and implements Serializable.
 */
public class CustomerRecord implements Serializable {
    private static final long serialVersionUID = 1L;

    // ----- Fields (minimum 5) -----
    private int customerId;          // key (usually auto-increment in DB)
    private String fullName;
    private String email;
    private String membershipLevel;
    private double accountBalance;

    /** No-arg constructor required by JavaBean conventions. */
    public CustomerRecord() {}

    // ----- Getters/Setters -----
    public int getCustomerId() { return customerId; }
    public void setCustomerId(int customerId) { this.customerId = customerId; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getMembershipLevel() { return membershipLevel; }
    public void setMembershipLevel(String membershipLevel) { this.membershipLevel = membershipLevel; }

    public double getAccountBalance() { return accountBalance; }
    public void setAccountBalance(double accountBalance) { this.accountBalance = accountBalance; }
}
