<%-- 
  File: movies.jsp
  Course/Module: CSD-430 Module (your module #)
  Purpose: Dynamic HTML page using JSP Scriptlets to display grouped movie records in tables.
  Author: Reed Bunnell
  Date: (enter date)

  Requirements met:
  - Scriptlets hold Java code
  - All HTML tags are outside Scriptlet sections
  - Uses external CSS
  - Data displayed in HTML tables
  - Data grouped into topical categories (Genre)
  - Includes title, field/record descriptions, and overall data description
  - Minimum 5 records with three fields
--%>

<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%
    // ----- Java (Scriptlet) Section: Data Model + Records -----

    // Simple "record" class to hold 3 fields
    class MovieRecord {
        String title;
        int year;
        String whyEnjoyed;

        MovieRecord(String title, int year, String whyEnjoyed) {
            this.title = title;
            this.year = year;
            this.whyEnjoyed = whyEnjoyed;
        }
    }

    // Group records by topical category (genre)
    java.util.LinkedHashMap<String, java.util.List<MovieRecord>> moviesByGenre =
            new java.util.LinkedHashMap<String, java.util.List<MovieRecord>>();

    java.util.List<MovieRecord> sciFi = new java.util.ArrayList<MovieRecord>();
    sciFi.add(new MovieRecord("Interstellar", 2014, "Big ideas + emotional story and stunning visuals."));
    sciFi.add(new MovieRecord("The Matrix", 1999, "Creative world-building and a classic mind-bender."));

    java.util.List<MovieRecord> drama = new java.util.ArrayList<MovieRecord>();
    drama.add(new MovieRecord("The Shawshank Redemption", 1994, "Hope-driven story with unforgettable characters."));
    drama.add(new MovieRecord("Whiplash", 2014, "Intense pace and a gripping performance-driven conflict."));

    java.util.List<MovieRecord> adventure = new java.util.ArrayList<MovieRecord>();
    adventure.add(new MovieRecord("The Lord of the Rings: The Fellowship of the Ring", 2001,
            "Epic journey and incredible world detail."));

    // Add to map in display order
    moviesByGenre.put("Science Fiction", sciFi);
    moviesByGenre.put("Drama", drama);
    moviesByGenre.put("Adventure/Fantasy", adventure);

    // Page-level descriptions
    String pageTitle = "Movies I’ve Enjoyed";
    String overallDescription =
            "This dynamic JSP page uses Java Scriptlets to generate HTML tables that display movie records. " +
            "Movies are grouped into topical categories (genres).";

    String fieldDescription =
            "Fields: Title (movie name), Year (release year), Why Enjoyed (short personal summary).";
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title><%= pageTitle %></title>
    <link rel="stylesheet" href="styles.css" />
</head>

<body>
<div class="container">
    <header class="header">
        <h1><%= pageTitle %></h1>
        <p class="overall"><strong>Overall data description:</strong> <%= overallDescription %></p>
        <p class="overall"><strong>Field description:</strong> <%= fieldDescription %></p>
        <p class="overall note">
            <strong>Record description:</strong> Each record represents one movie entry with exactly three fields.
        </p>
    </header>

    <main>
        <%
            // Iterate genres in the map (Java logic in Scriptlet)
            for (java.util.Map.Entry<String, java.util.List<MovieRecord>> entry : moviesByGenre.entrySet()) {
                String genre = entry.getKey();
                java.util.List<MovieRecord> records = entry.getValue();
        %>

        <!-- HTML outside scriptlets -->
        <section class="section">
            <h2 class="genreTitle"><%= genre %></h2>

            <table class="dataTable">
                <thead>
                <tr>
                    <th>Title</th>
                    <th>Year</th>
                    <th>Why I Enjoyed It</th>
                </tr>
                </thead>
                <tbody>
                <%
                    // Loop records (logic in Scriptlet, HTML tags outside)
                    for (MovieRecord r : records) {
                %>
                <tr>
                    <td><%= r.title %></td>
                    <td><%= r.year %></td>
                    <td><%= r.whyEnjoyed %></td>
                </tr>
                <%
                    }
                %>
                </tbody>
            </table>
        </section>

        <%
            } // end genre loop
        %>
    </main>

    <footer class="footer">
        <p>Generated dynamically using JSP Scriptlets (CSD-430).</p>
    </footer>
</div>
</body>
</html>
